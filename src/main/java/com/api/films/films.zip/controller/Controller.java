// src/main/java/com/api/films/controller/Controller.java

package com.api.films.controller;

import java.util.List;
import java.util.Optional;
import java.io.IOException; // Necessário para tratar o getBytes()

import com.api.films.model.Filmes;
import com.api.films.repository.FilmeRepository;
import com.api.films.dtos.FilmesDto;

// Adicionar importações para lidar com MultipartFile e JSON
import org.springframework.web.bind.annotation.RequestPart; // Importação essencial
import org.springframework.web.multipart.MultipartFile; // Importação essencial
import com.fasterxml.jackson.databind.ObjectMapper; // Usado para desserializar o JSON

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/filmes")
@CrossOrigin(origins = "http://localhost:5173")
public class Controller {

    @Autowired
    FilmeRepository repository;

    // ... (Métodos GET, DELETE, PUT permanecem os mesmos)

    // 1. GET ALL
    @SuppressWarnings("rawtypes")
    @GetMapping
    public ResponseEntity<List> getAll() {
        List<Filmes> listaFilmes = repository.findAll();
        return ResponseEntity.status(HttpStatus.OK).body(listaFilmes);
    }

    // 2. GET BY ID
    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Integer id) {
        Optional<Filmes> filmes = repository.findById(id);

        try {
            if (filmes.isPresent()) {
                return ResponseEntity.status(HttpStatus.OK).body(filmes.get());
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("<b>FILME NÃO ENCONTRADO</b>");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro interno do servidor");
        }
    }


    // 3. POST (SAVE) - IMPLEMENTAÇÃO COM UPLOAD DE IMAGEM 📸
    // URL Final: http://localhost:8080/filmes
    @PostMapping(consumes = {"multipart/form-data"}) // Consome dados multipart
    public ResponseEntity<?> save(
            @RequestPart("filme") String filmeJson, // Recebe o DTO como JSON String
            @RequestPart("imagem") MultipartFile imagemFile) { // Recebe o arquivo da imagem

        try {
            // 1. Desserializar o JSON do filme para o DTO
            ObjectMapper objectMapper = new ObjectMapper();
            FilmesDto dto = objectMapper.readValue(filmeJson, FilmesDto.class);

            // 2. Converter o MultipartFile para byte[]
            byte[] imagemBytes = imagemFile.getBytes();

            // 3. Criar e preencher a entidade Filmes
            var filmes = new Filmes();

            // Copia as propriedades de texto do DTO para o modelo
            BeanUtils.copyProperties(dto, filmes);

            // Define a imagem no modelo
            filmes.setImagem(imagemBytes);

            // 4. Salvar no repositório
            Filmes filmeSalvo = repository.save(filmes);

            return ResponseEntity.status(HttpStatus.CREATED).body(filmeSalvo);

        } catch (IOException e) {
            // Se houver erro na leitura do arquivo ou desserialização
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro ao processar dados ou arquivo de imagem.");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro interno do servidor durante o cadastro.");
        }
    }


    // 4. DELETE
    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete (@PathVariable Integer id) {
        Optional<Filmes> filmes = repository.findById(id);

        try {
            if (filmes.isPresent()) {
                repository.deleteById(id);
                return ResponseEntity.status(HttpStatus.OK).body("FILME DELETADO");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("FILME NÃO ENCONTRADO");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro interno do servidor");
        }
    }


    // 5. PUT (UPDATE)
    // Para atualizar a imagem, a requisição PUT também deve usar multipart/form-data.
    // Caso contrário, a imagem será sobrescrita com null/vazio se você usar JSON puro.
    @PutMapping(value = "/{id}", consumes = {"multipart/form-data", "application/json"})
    public ResponseEntity<?> put (
            @PathVariable Integer id,
            @RequestPart(value = "filme", required = false) String filmeJson,
            @RequestPart(value = "imagem", required = false) MultipartFile imagemFile) {

        Optional<Filmes> filmesOptional = repository.findById(id);

        try {
            if (filmesOptional.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("FILME NÃO ENCONTRADO");
            }

            Filmes filmeModel = filmesOptional.get();

            // 1. Processar DTO (Se filmeJson for fornecido)
            if (filmeJson != null) {
                ObjectMapper objectMapper = new ObjectMapper();
                FilmesDto dto = objectMapper.readValue(filmeJson, FilmesDto.class);
                BeanUtils.copyProperties(dto, filmeModel);
            }

            // 2. Processar Imagem (Se imagemFile for fornecido)
            if (imagemFile != null && !imagemFile.isEmpty()) {
                filmeModel.setImagem(imagemFile.getBytes());
            }

            // 3. Salvar
            return ResponseEntity.status(HttpStatus.OK).body(repository.save(filmeModel));

        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro ao processar dados ou arquivo de imagem.");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro interno do servidor");
        }
    }
}