package com.api.films.dtos;

// Este DTO (Data Transfer Object) é usado para receber os dados
// do formulário de registro do React.
public record RegistroDto(String username, String password) {
}