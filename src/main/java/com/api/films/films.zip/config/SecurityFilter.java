// src/main/java/com/api/films/config/SecurityFilter.java
package com.api.films.config;

import com.api.films.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component // Diz ao Spring que este é um componente
public class SecurityFilter extends OncePerRequestFilter {

    @Autowired
    private TokenService tokenService; // Nosso leitor/gerador de token

    @Autowired
    private UsuarioRepository usuarioRepository; // Nosso buscador de usuários

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        // 1. Tenta recuperar o token da requisição
        var token = this.recuperarToken(request);

        // 2. Se um token foi encontrado...
        if (token != null) {
            // 3. Valida o token e pega o username (subject) de dentro dele
            var username = tokenService.validarToken(token);

            // 4. Se o username não for vazio (token válido)...
            if (!username.isEmpty()) {
                // 5. Busca o usuário no banco de dados
                UserDetails usuario = usuarioRepository.findByUsername(username)
                        .orElseThrow(() -> new RuntimeException("Usuário não encontrado no filtro"));

                // 6. Cria uma "credencial" de autenticação para o Spring
                var authentication = new UsernamePasswordAuthenticationToken(usuario, null, usuario.getAuthorities());

                // 7. Salva essa credencial no "contexto" do Spring Security
                // Isso diz ao Spring: "Este usuário está logado PARA ESTA REQUISIÇÃO"
                SecurityContextHolder.getContext().setAuthentication(authentication);
            }
        }

        // 8. Independentemente de ter token ou não, continua a requisição
        filterChain.doFilter(request, response);
    }

    // Método auxiliar para pegar o token do Header "Authorization"
    private String recuperarToken(HttpServletRequest request) {
        var authHeader = request.getHeader("Authorization");
        if (authHeader == null) {
            return null;
        }
        // Retorna o token, removendo o "Bearer " do início
        return authHeader.replace("Bearer ", "");
    }
}