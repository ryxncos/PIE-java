// src/main/java/com/api/films/model/Usuario.java
package com.api.films.model;

import javax.persistence.*;
import java.util.Collection;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

@Entity(name = "usuarios")
@Table(name = "usuarios")
public class Usuario implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(unique = true) // Garante que o username seja único
    private String username; // No React, usamos o e-mail como username

    private String password; // A senha será armazenada com hash (ex: bcrypt)

    // --- Construtores, Getters e Setters ---
    public Usuario() {}

    public Usuario(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    // --- Métodos do UserDetails (Spring Security) ---
    // Esses métodos são necessários para o Spring Security

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true; // Conta nunca expira
    }

    @Override
    public boolean isAccountNonLocked() {
        return true; // Conta nunca é bloqueada
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true; // Credenciais nunca expiram
    }

    @Override
    public boolean isEnabled() {
        return true; // Conta está sempre habilitada
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return null; // Não estamos usando "Roles" (ex: ADMIN, USER) por enquanto
    }
}