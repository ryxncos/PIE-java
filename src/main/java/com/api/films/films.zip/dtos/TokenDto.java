package com.api.films.dtos;

// DTO para enviar o token JWT de volta para o React
public record TokenDto(String token) {
}