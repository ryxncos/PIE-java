package com.api.films.dtos;

// DTO para receber os dados de login (username e password)
public record LoginDto(String username, String password) {
}