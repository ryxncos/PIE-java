// src/main/java/com/api/films/repository/UsuarioRepository.java
package com.api.films.repository;

import com.api.films.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {

    // O Spring Security vai usar este método para encontrar o usuário
    Optional<Usuario> findByUsername(String username);
}