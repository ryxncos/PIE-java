// src/main/java/com/api/films/dtos/FilmesDto.java

package com.api.films.dtos;

// Este Record define os campos de texto que serão mapeados a partir do JSON
// enviado pelo frontend (que estará dentro do FormData).
public record FilmesDto(
        String titulo,
        String diretor,
        String genero,
        String anoLancamento,
        String sinopse,
        String elenco,
        String review
) {

}