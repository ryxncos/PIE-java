package com.api.films.config;

import com.api.films.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class AutenticacaoService implements UserDetailsService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    // Este é o método que o Spring Security chama quando tentamos fazer login
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Ele usa o método que criamos no UsuarioRepository para buscar o usuário
        return usuarioRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Usuário não encontrado"));
    }
}