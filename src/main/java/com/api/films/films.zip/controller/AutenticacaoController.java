package com.api.films.controller;

import com.api.films.dtos.LoginDto;
import com.api.films.dtos.RegistroDto;
import com.api.films.dtos.TokenDto;
import com.api.films.config.TokenService;
import com.api.films.model.Usuario;
import com.api.films.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:5173")
public class AutenticacaoController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // --- NOVAS INJEÇÕES ---
    @Autowired
    private AuthenticationManager authenticationManager; // O "chefe" da autenticação

    @Autowired
    private TokenService tokenService; // O gerador de token

    // --- MÉTODO DE REGISTRO (Continua igual) ---
    @PostMapping("/register")
    public ResponseEntity<?> registrarUsuario(@RequestBody RegistroDto registroDto) {
        if (usuarioRepository.findByUsername(registroDto.username()).isPresent()) {
            return ResponseEntity.badRequest().body("Erro: Nome de usuário (e-mail) já está em uso!");
        }
        String senhaCriptografada = passwordEncoder.encode(registroDto.password());
        Usuario novoUsuario = new Usuario(registroDto.username(), senhaCriptografada);
        usuarioRepository.save(novoUsuario);
        return ResponseEntity.ok("Usuário registrado com sucesso!");
    }

    // --- NOVO MÉTODO DE LOGIN ---
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginDto loginDto) {
        try {
            // 1. Cria um "pacote" com o username e senha
            var usernamePassword = new UsernamePasswordAuthenticationToken(
                    loginDto.username(),
                    loginDto.password()
            );

            // 2. Tenta autenticar (o Spring Security vai chamar nosso AutenticacaoService)
            // Se a senha estiver errada, ele joga uma exceção
            var auth = this.authenticationManager.authenticate(usernamePassword);

            // 3. Se deu certo, pega o usuário
            var usuario = (Usuario) auth.getPrincipal();

            // 4. Gera o token
            var token = tokenService.gerarToken(usuario);

            // 5. Retorna o token para o React
            return ResponseEntity.ok(new TokenDto(token));

        } catch (Exception e) {
            // Se a autenticação falhar (senha errada, usuário não existe)
            return ResponseEntity.status(401).body("Credenciais inválidas.");
        }
    }
}