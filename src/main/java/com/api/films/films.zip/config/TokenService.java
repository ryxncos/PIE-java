// src/main/java/com/api/films/config/TokenService.java
package com.api.films.config;

import com.api.films.model.Usuario;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException; // 1. IMPORTAR
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

@Service
public class TokenService {

    @Value("${api.security.token.secret}")
    private String secret;

    // Método para GERAR o token (continua igual)
    public String gerarToken(Usuario usuario) {
        try {
            Algorithm algoritmo = Algorithm.HMAC256(secret);
            String token = JWT.create()
                    .withIssuer("api-films")
                    .withSubject(usuario.getUsername())
                    .withExpiresAt(getExpirationDate())
                    .sign(algoritmo);
            return token;
        } catch (JWTCreationException exception) {
            throw new RuntimeException("Erro ao gerar token JWT", exception);
        }
    }

    // --- NOVO MÉTODO PARA VALIDAR O TOKEN ---
    // Este método vai ler o token e dizer se é válido
    public String validarToken(String token) {
        try {
            Algorithm algoritmo = Algorithm.HMAC256(secret);
            return JWT.require(algoritmo)
                    .withIssuer("api-films") // Verifica se o "emissor" é o mesmo
                    .build()
                    .verify(token) // Tenta verificar o token
                    .getSubject(); // Se for válido, retorna o "dono" (o username)

        } catch (JWTVerificationException exception) {
            // Se o token for inválido, expirado, ou modificado, retorna vazio
            return "";
        }
    }
    // --- FIM DO NOVO MÉTODO ---

    // Método de expiração (continua igual)
    private Instant getExpirationDate() {
        return LocalDateTime.now().plusHours(2).toInstant(ZoneOffset.of("-03:00"));
    }
}